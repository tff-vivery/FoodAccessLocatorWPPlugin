<?php //Pantry Locator - Shortcode

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function food_access_locator_shortcode() {
    $environmentsetting = trim(strtoupper(get_option("food_access_locator_options")['environment']));

    if ($environmentsetting == "GCFDPRODUCTION") {
        $BaseUrl = 'https://client.foodaccessportal.org/';
    } 
    elseif ($environmentsetting == "MAINPRODUCTION") {
        $BaseUrl = 'https://accessfood.org/';
    }
    elseif ($environmentsetting == "MAINSTAGING") {
        $BaseUrl = 'https://staging.accessfood.org/';
    }
    elseif ($environmentsetting == "DEMO") {
        $BaseUrl = 'https://demo.accessfood.org/';
    }
    elseif ($environmentsetting == "OPTIMUSPRODUCTION") {
        $BaseUrl = 'https://optimus.accessfood.org/';
    }
    elseif ($environmentsetting == "OPTIMUSSTAGING") {
        $BaseUrl = 'https://optimus-staging.accessfood.org/';
    }
    else {
        $BaseUrl = 'https://staging.accessfood.org/';
    }


    return
        '<!-- Plugin Version: 3.0.1 -->'
        . '<iframe id="FoodAccessFrame" src="' . $BaseUrl
        . '?RegionToken=' . urlencode(get_option("food_access_locator_options")['region_token']) 
        . '" style="overflow:hidden; overflow-x:hidden; overflow-y:hidden; height:800px; width:100%; position:relative; top:0px; left:0px; right:0px; bottom:0px; border:0;" allow="geolocation">' . $environmentsetting
        . '</iframe>';
}
add_shortcode( 'food_access_locator', 'food_access_locator_shortcode' );